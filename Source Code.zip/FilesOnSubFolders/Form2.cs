﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FilesOnSubFolders
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void AboutForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Hakkında formu kapatıldığında, ana formun etkinliğini geri kazandır
            if (Owner != null)
            {
                Owner.Enabled = true;
            }
        }
    }
}
