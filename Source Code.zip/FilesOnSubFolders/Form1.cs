﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FilesOnSubFolders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnKaynakSec_Click(object sender, EventArgs e)
        {
            // Kullanıcıdan kaynak klasörü seçmesini iste
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                txtKaynakKlasor.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void btnHedefSec_Click(object sender, EventArgs e)
        {
            // Kullanıcıdan hedef klasörü seçmesini iste
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                txtHedefKlasor.Text = folderBrowserDialog.SelectedPath;
            }
        }


        private void btnTasi_Click(object sender, EventArgs e)
        {
            // Kullanıcının seçtiği kaynak ve hedef klasörlerini al
            string kaynakKlasor = txtKaynakKlasor.Text;
            string hedefKlasor = txtHedefKlasor.Text;

            // Kaynak ve hedef klasörlerinin boş olup olmadığını kontrol et
            if (string.IsNullOrEmpty(kaynakKlasor) || string.IsNullOrEmpty(hedefKlasor))
            {
                MessageBox.Show("Lütfen kaynak ve hedef klasörleri seçin.");
                return;
            }

            // Kullanıcıya onay iletişi göster
            DialogResult result = MessageBox.Show("Dosyaları taşımak istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    // Kaynak klasördeki tüm dosyaların sayısını al
                    string[] allFiles = Directory.GetFiles(kaynakKlasor, "*.*", SearchOption.AllDirectories);
                    int totalFiles = allFiles.Length;

                    // İlerleme çubuğunu ayarla
                    progressBar.Maximum = totalFiles;
                    progressBar.Value = 0;

                    // Her bir dosyayı hedef klasöre taşı
                    foreach (string file in allFiles)
                    {
                        string destFile = Path.Combine(hedefKlasor, Path.GetFileName(file));
                        File.Move(file, destFile);

                        // Dosya taşıma işlemi tamamlandığında ilerleme çubuğunu güncelle
                        progressBar.Value++;

                        // İlerleme yüzdesini hesapla ve etikete yaz
                        int percent = (int)(((double)progressBar.Value / (double)progressBar.Maximum) * 100);
                        lblProgress.Text = percent + "%";
                    }

                    MessageBox.Show("Dosyalar başarıyla taşındı!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hata oluştu: " + ex.Message);
                }
            }
        }

        private void btnHakkinda_Click(object sender, EventArgs e)
        {
            // Yeni bir Hakkında formu oluştur
            Form2 aboutForm = new Form2();

            // Ana formun tıklanmaz hale gelmesini sağla
            this.Enabled = false;

            // Hakkında formunu göster
            aboutForm.ShowDialog();

            // Hakkında formu kapatıldığında ana formu tekrar etkin hale getir
            this.Enabled = true;
        }
    }
}