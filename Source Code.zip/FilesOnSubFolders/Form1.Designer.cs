﻿namespace FilesOnSubFolders
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnTasi = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.lblProgress = new System.Windows.Forms.Label();
            this.txtKaynakKlasor = new System.Windows.Forms.TextBox();
            this.txtHedefKlasor = new System.Windows.Forms.TextBox();
            this.btnHakkinda = new System.Windows.Forms.Button();
            this.btnKaynakSec = new System.Windows.Forms.Button();
            this.btnHedefSec = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // btnTasi
            // 
            this.btnTasi.Location = new System.Drawing.Point(12, 124);
            this.btnTasi.Name = "btnTasi";
            this.btnTasi.Size = new System.Drawing.Size(331, 49);
            this.btnTasi.TabIndex = 0;
            this.btnTasi.Text = "TAŞI";
            this.btnTasi.UseVisualStyleBackColor = true;
            this.btnTasi.Click += new System.EventHandler(this.btnTasi_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(12, 74);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(331, 39);
            this.progressBar.TabIndex = 1;
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.Location = new System.Drawing.Point(366, 86);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(21, 13);
            this.lblProgress.TabIndex = 2;
            this.lblProgress.Text = "0%";
            // 
            // txtKaynakKlasor
            // 
            this.txtKaynakKlasor.Location = new System.Drawing.Point(12, 12);
            this.txtKaynakKlasor.Name = "txtKaynakKlasor";
            this.txtKaynakKlasor.Size = new System.Drawing.Size(331, 20);
            this.txtKaynakKlasor.TabIndex = 3;
            // 
            // txtHedefKlasor
            // 
            this.txtHedefKlasor.Location = new System.Drawing.Point(12, 43);
            this.txtHedefKlasor.Name = "txtHedefKlasor";
            this.txtHedefKlasor.Size = new System.Drawing.Size(331, 20);
            this.txtHedefKlasor.TabIndex = 4;
            // 
            // btnHakkinda
            // 
            this.btnHakkinda.Location = new System.Drawing.Point(349, 124);
            this.btnHakkinda.Name = "btnHakkinda";
            this.btnHakkinda.Size = new System.Drawing.Size(53, 49);
            this.btnHakkinda.TabIndex = 5;
            this.btnHakkinda.Text = "Bilgi";
            this.btnHakkinda.UseVisualStyleBackColor = true;
            this.btnHakkinda.Click += new System.EventHandler(this.btnHakkinda_Click);
            // 
            // btnKaynakSec
            // 
            this.btnKaynakSec.Location = new System.Drawing.Point(349, 12);
            this.btnKaynakSec.Name = "btnKaynakSec";
            this.btnKaynakSec.Size = new System.Drawing.Size(53, 23);
            this.btnKaynakSec.TabIndex = 6;
            this.btnKaynakSec.Text = "Kaynak";
            this.btnKaynakSec.UseVisualStyleBackColor = true;
            this.btnKaynakSec.Click += new System.EventHandler(this.btnKaynakSec_Click);
            // 
            // btnHedefSec
            // 
            this.btnHedefSec.Location = new System.Drawing.Point(349, 43);
            this.btnHedefSec.Name = "btnHedefSec";
            this.btnHedefSec.Size = new System.Drawing.Size(53, 23);
            this.btnHedefSec.TabIndex = 7;
            this.btnHedefSec.Text = "Hedef";
            this.btnHedefSec.UseVisualStyleBackColor = true;
            this.btnHedefSec.Click += new System.EventHandler(this.btnHedefSec_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 181);
            this.Controls.Add(this.btnHedefSec);
            this.Controls.Add(this.btnKaynakSec);
            this.Controls.Add(this.btnHakkinda);
            this.Controls.Add(this.txtHedefKlasor);
            this.Controls.Add(this.txtKaynakKlasor);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.btnTasi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(430, 220);
            this.MinimumSize = new System.Drawing.Size(430, 220);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dosya Ayıklayıcı";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTasi;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.TextBox txtKaynakKlasor;
        private System.Windows.Forms.TextBox txtHedefKlasor;
        private System.Windows.Forms.Button btnHakkinda;
        private System.Windows.Forms.Button btnKaynakSec;
        private System.Windows.Forms.Button btnHedefSec;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

